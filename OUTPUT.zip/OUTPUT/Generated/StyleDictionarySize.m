
//
// StyleDictionarySize.m
//
// Do not edit directly
// Generated on Tue, 21 Jan 2020 13:59:08 GMT
//

#import "StyleDictionarySize.h"



float const StyleDictionarySizeFontTiny = 12.00f;
float const StyleDictionarySizeFontSmall = 14.00f;
float const StyleDictionarySizeFontMedium = 16.00f;
float const StyleDictionarySizeFontLarge = 20.00f;
float const StyleDictionarySizeFontXl = 24.00f;
float const StyleDictionarySizeFontXxl = 32.00f;
float const StyleDictionarySizeFontXxxl = 48.00f;
float const StyleDictionarySizeFontBase = 16.00f;
float const StyleDictionarySizeIconSmall = 24.00f;
float const StyleDictionarySizeIconBase = 32.00f;
float const StyleDictionarySizeIconLarge = 40.00f;
float const StyleDictionarySizeIconXl = 48.00f;
float const StyleDictionarySizeIconXxl = 80.00f;
float const StyleDictionarySizePaddingTiny = 4.00f;
float const StyleDictionarySizePaddingSmall = 8.00f;
float const StyleDictionarySizePaddingMedium = 16.00f;
float const StyleDictionarySizePaddingLarge = 24.00f;
float const StyleDictionarySizePaddingXl = 32.00f;
float const StyleDictionarySizePaddingXxl = 48.00f;
float const StyleDictionarySizePaddingBase = 16.00f;
