
// StyleDictionarySize.h
//
// Do not edit directly
// Generated on Tue, 21 Jan 2020 13:59:08 GMT
//

#import <Foundation/Foundation.h>



extern float const StyleDictionarySizeFontTiny;
extern float const StyleDictionarySizeFontSmall;
extern float const StyleDictionarySizeFontMedium;
extern float const StyleDictionarySizeFontLarge;
extern float const StyleDictionarySizeFontXl;
extern float const StyleDictionarySizeFontXxl;
extern float const StyleDictionarySizeFontXxxl;
extern float const StyleDictionarySizeFontBase;
extern float const StyleDictionarySizeIconSmall;
extern float const StyleDictionarySizeIconBase;
extern float const StyleDictionarySizeIconLarge;
extern float const StyleDictionarySizeIconXl;
extern float const StyleDictionarySizeIconXxl;
extern float const StyleDictionarySizePaddingTiny;
extern float const StyleDictionarySizePaddingSmall;
extern float const StyleDictionarySizePaddingMedium;
extern float const StyleDictionarySizePaddingLarge;
extern float const StyleDictionarySizePaddingXl;
extern float const StyleDictionarySizePaddingXxl;
extern float const StyleDictionarySizePaddingBase;
